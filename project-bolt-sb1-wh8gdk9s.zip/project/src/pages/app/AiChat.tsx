import React, { useState } from 'react';
import { Mic, Image, Send, Sparkles } from 'lucide-react';
import Header from '../../components/layout/Header';

interface ChatMessage {
  sender: 'user' | 'ai';
  text: string;
  timestamp: Date;
}

interface SuggestionProps {
  text: string;
  onClick: () => void;
}

const Suggestion: React.FC<SuggestionProps> = ({ text, onClick }) => {
  return (
    <button 
      onClick={onClick}
      className="py-2 px-4 bg-primary-50 text-primary-700 rounded-full text-sm whitespace-nowrap hover:bg-primary-100 transition-colors"
    >
      {text}
    </button>
  );
};

const AiChat: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      sender: 'ai',
      text: 'नमस्ते! I\'m your AI Architect Assistant. How can I help you with your home today?',
      timestamp: new Date(),
    }
  ]);
  const [inputText, setInputText] = useState('');
  
  const suggestions = [
    'How to design 2BHK?',
    'Best Vastu colors?',
    'Cost-saving tips',
    'Kitchen layout ideas',
    'Modern home trends',
  ];
  
  const handleSend = () => {
    if (!inputText.trim()) return;
    
    // Add user message
    const userMessage: ChatMessage = {
      sender: 'user',
      text: inputText,
      timestamp: new Date(),
    };
    
    setMessages((prev) => [...prev, userMessage]);
    setInputText('');
    
    // Simulate AI response (in a real app, this would be an API call)
    setTimeout(() => {
      let response = '';
      
      if (inputText.toLowerCase().includes('2bhk')) {
        response = 'For a 2BHK home, I recommend:\n\n1. An open-concept living and dining area\n2. Kitchen with modular cabinets\n3. Master bedroom with attached bathroom\n4. Second bedroom for guests or children\n5. Use light colors to make spaces feel larger\n\nThe ideal size would be 800-1000 sq.ft. Would you like to see some layout options?';
      } else if (inputText.toLowerCase().includes('vastu')) {
        response = 'According to Vastu principles:\n\n- North-East: Place for worship, water sources\n- East: Main entrance for positive energy\n- South-East: Kitchen is ideal here\n- South: Master bedroom for stability\n- South-West: Storage rooms, heavy items\n- West: Children\'s room or guest room\n- North-West: Less used areas like storage\n- North: Treasury, living areas';
      } else {
        response = 'I\'d be happy to help with that! Could you provide a bit more information about your specific requirements so I can give you the most relevant advice?';
      }
      
      const aiMessage: ChatMessage = {
        sender: 'ai',
        text: response,
        timestamp: new Date(),
      };
      
      setMessages((prev) => [...prev, aiMessage]);
    }, 1000);
  };
  
  const handleSuggestionClick = (suggestion: string) => {
    setInputText(suggestion);
    
    // Optional: automatically send the suggestion
    // This simulates the user clicking the suggestion and then clicking send
    const userMessage: ChatMessage = {
      sender: 'user',
      text: suggestion,
      timestamp: new Date(),
    };
    
    setMessages((prev) => [...prev, userMessage]);
    
    // Simulate AI response
    setTimeout(() => {
      let response = '';
      
      if (suggestion.includes('2BHK')) {
        response = 'For a well-designed 2BHK home (700-900 sq ft), I recommend:\n\n1. Entry opens to living area (180-220 sq ft)\n2. Living connects to dining (80-100 sq ft)\n3. Semi-open kitchen (70-90 sq ft) with breakfast counter\n4. Master bedroom (120-150 sq ft) with attached bath\n5. Second bedroom (100-120 sq ft)\n6. Common bathroom (35-45 sq ft)\n7. Small balcony if possible (30-40 sq ft)\n\nWould you like specific layout suggestions?';
      } else if (suggestion.includes('Vastu colors')) {
        response = 'According to Vastu, optimal colors for each direction are:\n\n- North: Blue, light blue (water element)\n- East: Green, light yellow (wood element)\n- South: Red, orange, pink (fire element)\n- West: White, light gray (metal element)\n- North-East: Light colors like sky blue (water & earth)\n- South-East: Orange, purple (fire & earth)\n- South-West: Earthy tones like brown (earth element)\n- North-West: White, cream, gray (air & metal)\n\nFor main living areas, light yellows and greens promote positive energy.';
      } else if (suggestion.includes('Cost-saving')) {
        response = 'Here are practical cost-saving tips for home construction:\n\n1. Use standard size materials to minimize cutting waste\n2. Choose RCC over RBC ceiling\n3. Opt for ready-made doors and windows\n4. Use ceramic tiles instead of marble/granite where possible\n5. Invest in quality electrical materials to avoid future repairs\n6. Consider prefabricated structures for certain elements\n7. Phase your construction if working with limited budget\n8. Buy materials directly from manufacturers when possible\n9. Prioritize energy efficiency for long-term savings\n\nI can provide more detailed recommendations for specific areas if needed!';
      } else {
        response = 'I\'d be happy to help with that! Could you provide a bit more information about your specific requirements so I can give you the most relevant advice?';
      }
      
      const aiMessage: ChatMessage = {
        sender: 'ai',
        text: response,
        timestamp: new Date(),
      };
      
      setMessages((prev) => [...prev, aiMessage]);
    }, 1000);
    
    setInputText('');
  };
  
  return (
    <div className="min-h-screen flex flex-col bg-neutral-50">
      <Header />
      
      <main className="flex-grow flex flex-col container mx-auto px-4 py-8 max-w-4xl">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-2xl font-bold text-neutral-900">AI Architect</h1>
            <p className="text-neutral-600">
              Ask anything about interior, Vastu, or architecture
            </p>
          </div>
          
          <div className="bg-primary-100 text-primary-700 px-4 py-1 rounded-full text-sm flex items-center">
            <Sparkles size={16} className="mr-1" />
            <span>GPT-4 Powered</span>
          </div>
        </div>
        
        {/* Suggestions */}
        <div className="mb-6 flex gap-2 overflow-x-auto pb-2 -mx-1 px-1">
          {suggestions.map((suggestion, index) => (
            <Suggestion 
              key={index} 
              text={suggestion} 
              onClick={() => handleSuggestionClick(suggestion)} 
            />
          ))}
        </div>
        
        {/* Chat Messages */}
        <div className="flex-grow bg-white rounded-lg shadow-md overflow-hidden flex flex-col">
          <div className="flex-grow overflow-y-auto p-4 space-y-4">
            {messages.map((message, index) => (
              <div 
                key={index} 
                className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div 
                  className={`max-w-[80%] rounded-lg p-3 ${
                    message.sender === 'user' 
                      ? 'bg-primary-500 text-white' 
                      : 'bg-neutral-100 text-neutral-800'
                  }`}
                >
                  <p className="whitespace-pre-line">{message.text}</p>
                  <p className={`text-xs mt-1 ${
                    message.sender === 'user' 
                      ? 'text-primary-100' 
                      : 'text-neutral-500'
                  }`}>
                    {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </p>
                </div>
              </div>
            ))}
          </div>
          
          {/* Input Area */}
          <div className="p-4 border-t border-neutral-200 flex items-center gap-2">
            <button className="p-2 text-neutral-500 hover:text-neutral-700 rounded-full hover:bg-neutral-100">
              <Mic size={20} />
            </button>
            <button className="p-2 text-neutral-500 hover:text-neutral-700 rounded-full hover:bg-neutral-100">
              <Image size={20} />
            </button>
            
            <input 
              type="text" 
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Ask anything about your home design..."
              className="flex-grow py-2 px-4 border border-neutral-300 rounded-lg focus:outline-none focus:border-primary-500"
            />
            
            <button 
              onClick={handleSend}
              disabled={!inputText.trim()}
              className={`p-2 rounded-full ${
                inputText.trim() 
                  ? 'bg-primary-500 text-white' 
                  : 'bg-neutral-200 text-neutral-400'
              }`}
            >
              <Send size={20} />
            </button>
          </div>
        </div>
      </main>
    </div>
  );
};

export default AiChat;