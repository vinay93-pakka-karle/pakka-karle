import React, { useState } from 'react';
import { Camera, MapPin, Home, DollarSign, Users, Trash2, Edit2, Tag, BadgeCheck, Upload } from 'lucide-react';
import Header from '../../components/layout/Header';
import Button from '../../components/ui/Button';
import Card, { CardContent } from '../../components/ui/Card';

interface ListingFormData {
  type: 'sell' | 'rent';
  propertyType: string;
  bedrooms: string;
  bathrooms: string;
  price: string;
  address: string;
  description: string;
  renovateOption: boolean;
}

const PropertyListing: React.FC = () => {
  const [formData, setFormData] = useState<ListingFormData>({
    type: 'sell',
    propertyType: 'apartment',
    bedrooms: '2',
    bathrooms: '2',
    price: '',
    address: '',
    description: '',
    renovateOption: false
  });
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };
  
  const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, checked } = e.target;
    setFormData({
      ...formData,
      [name]: checked
    });
  };
  
  const handleTypeChange = (type: 'sell' | 'rent') => {
    setFormData({
      ...formData,
      type
    });
  };
  
  return (
    <div className="min-h-screen flex flex-col bg-neutral-50">
      <Header />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-2xl font-bold text-neutral-900">List Your Property</h1>
            <p className="text-neutral-600">
              Sell or rent your property with zero commission
            </p>
          </div>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <Card className="mb-8">
              <CardContent>
                <h2 className="text-lg font-semibold mb-4">Property Details</h2>
                
                <div className="grid grid-cols-1 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-neutral-700 mb-2">
                      I want to:
                    </label>
                    <div className="flex space-x-4">
                      <button
                        type="button"
                        className={`px-4 py-2 rounded-lg border ${
                          formData.type === 'sell'
                            ? 'bg-primary-50 border-primary-500 text-primary-700'
                            : 'border-neutral-300 text-neutral-700'
                        }`}
                        onClick={() => handleTypeChange('sell')}
                      >
                        Sell Property
                      </button>
                      <button
                        type="button"
                        className={`px-4 py-2 rounded-lg border ${
                          formData.type === 'rent'
                            ? 'bg-primary-50 border-primary-500 text-primary-700'
                            : 'border-neutral-300 text-neutral-700'
                        }`}
                        onClick={() => handleTypeChange('rent')}
                      >
                        Rent Property
                      </button>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-neutral-700 mb-2">
                        Property Type
                      </label>
                      <select
                        name="propertyType"
                        value={formData.propertyType}
                        onChange={handleChange}
                        className="w-full px-3 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500"
                      >
                        <option value="apartment">Apartment</option>
                        <option value="house">Independent House</option>
                        <option value="villa">Villa</option>
                        <option value="plot">Plot/Land</option>
                        <option value="commercial">Commercial Space</option>
                      </select>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-neutral-700 mb-2">
                        {formData.type === 'sell' ? 'Price (₹)' : 'Monthly Rent (₹)'}
                      </label>
                      <input
                        type="text"
                        name="price"
                        value={formData.price}
                        onChange={handleChange}
                        placeholder={formData.type === 'sell' ? 'e.g., 50,00,000' : 'e.g., 25,000'}
                        className="w-full px-3 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500"
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-neutral-700 mb-2">
                        Bedrooms
                      </label>
                      <select
                        name="bedrooms"
                        value={formData.bedrooms}
                        onChange={handleChange}
                        className="w-full px-3 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500"
                      >
                        <option value="1">1 BHK</option>
                        <option value="2">2 BHK</option>
                        <option value="3">3 BHK</option>
                        <option value="4">4 BHK</option>
                        <option value="5+">5+ BHK</option>
                      </select>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-neutral-700 mb-2">
                        Bathrooms
                      </label>
                      <select
                        name="bathrooms"
                        value={formData.bathrooms}
                        onChange={handleChange}
                        className="w-full px-3 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500"
                      >
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5+">5+</option>
                      </select>
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-neutral-700 mb-2">
                      Address
                    </label>
                    <input
                      type="text"
                      name="address"
                      value={formData.address}
                      onChange={handleChange}
                      placeholder="Full property address"
                      className="w-full px-3 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-neutral-700 mb-2">
                      Description
                    </label>
                    <textarea
                      name="description"
                      value={formData.description}
                      onChange={handleChange}
                      rows={4}
                      placeholder="Describe your property, highlight special features..."
                      className="w-full px-3 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="mb-8">
              <CardContent>
                <h2 className="text-lg font-semibold mb-4">Photos & Videos</h2>
                
                <div className="border-2 border-dashed border-neutral-300 rounded-lg p-8 text-center mb-6">
                  <div className="flex flex-col items-center">
                    <Camera size={40} className="text-neutral-400 mb-3" />
                    <h3 className="text-lg font-medium text-neutral-700 mb-1">Upload Photos & Videos</h3>
                    <p className="text-neutral-500 mb-4">Drag & drop or click to upload (max 10 files)</p>
                    
                    <Button 
                      variant="outline" 
                      leftIcon={<Upload size={16} />}
                    >
                      Select Files
                    </Button>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {[1, 2, 3, 4].map((item) => (
                    <div key={item} className="relative border border-neutral-300 rounded-lg overflow-hidden bg-neutral-200 aspect-square flex items-center justify-center">
                      <div className="text-neutral-400">Photo {item}</div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent>
                <div className="flex items-start">
                  <input
                    type="checkbox"
                    id="renovateOption"
                    name="renovateOption"
                    checked={formData.renovateOption}
                    onChange={handleCheckboxChange}
                    className="mt-1 h-4 w-4 text-primary-600 border-neutral-300 rounded focus:ring-primary-500"
                  />
                  <div className="ml-3">
                    <label htmlFor="renovateOption" className="font-medium text-neutral-700">
                      Renovate before listing?
                    </label>
                    <p className="text-neutral-500 text-sm">
                      Our experts can help renovate your property to increase its value. We'll handle everything from repairs to interior design.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div>
            <Card className="sticky top-4">
              <CardContent>
                <div className="bg-primary-50 text-primary-700 rounded-lg p-3 mb-6 flex items-center">
                  <BadgeCheck size={20} className="mr-2" />
                  <span className="font-medium">Zero Commission Forever</span>
                </div>
                
                <h2 className="text-lg font-semibold mb-4">Listing Summary</h2>
                
                <div className="space-y-4 mb-6">
                  <div className="flex">
                    <Tag size={18} className="text-neutral-500 mr-3 flex-shrink-0" />
                    <div>
                      <p className="font-medium">Type</p>
                      <p className="text-neutral-600">
                        {formData.type === 'sell' ? 'For Sale' : 'For Rent'} - {formData.propertyType}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex">
                    <DollarSign size={18} className="text-neutral-500 mr-3 flex-shrink-0" />
                    <div>
                      <p className="font-medium">Price</p>
                      <p className="text-neutral-600">
                        {formData.price ? `₹${formData.price}` : '-'} 
                        {formData.type === 'rent' && '/month'}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex">
                    <Home size={18} className="text-neutral-500 mr-3 flex-shrink-0" />
                    <div>
                      <p className="font-medium">Property Details</p>
                      <p className="text-neutral-600">
                        {formData.bedrooms} BHK, {formData.bathrooms} Bathroom
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex">
                    <MapPin size={18} className="text-neutral-500 mr-3 flex-shrink-0" />
                    <div>
                      <p className="font-medium">Location</p>
                      <p className="text-neutral-600">
                        {formData.address || '-'}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex">
                    <Users size={18} className="text-neutral-500 mr-3 flex-shrink-0" />
                    <div>
                      <p className="font-medium">Visibility</p>
                      <p className="text-neutral-600">
                        Your listing will be visible to thousands of potential buyers
                      </p>
                    </div>
                  </div>
                </div>
                
                <Button 
                  variant="primary" 
                  fullWidth
                  className="mb-3"
                >
                  Post for Free
                </Button>
                
                <div className="flex justify-center space-x-4">
                  <button className="text-neutral-600 flex items-center">
                    <Edit2 size={16} className="mr-1" />
                    <span>Edit</span>
                  </button>
                  <button className="text-neutral-600 flex items-center">
                    <Trash2 size={16} className="mr-1" />
                    <span>Clear</span>
                  </button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
};

export default PropertyListing;