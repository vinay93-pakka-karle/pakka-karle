import React, { useState } from 'react';
import { Move, Sofa, Bed, Tv, Grid as Fridge, Bath, Palette, Save, Share2, Download, MessageCircle } from 'lucide-react';
import Header from '../../components/layout/Header';
import Button from '../../components/ui/Button';

interface DesignElementProps {
  icon: React.ReactNode;
  label: string;
  active?: boolean;
  onClick?: () => void;
}

const DesignElement: React.FC<DesignElementProps> = ({ 
  icon, 
  label, 
  active = false,
  onClick 
}) => {
  return (
    <div 
      className={`flex flex-col items-center p-3 rounded-lg cursor-pointer transition-colors ${
        active ? 'bg-primary-100 text-primary-600' : 'hover:bg-neutral-100'
      }`}
      onClick={onClick}
    >
      <div className="mb-1">{icon}</div>
      <span className="text-sm">{label}</span>
    </div>
  );
};

const HomeDesigner: React.FC = () => {
  const [activeElement, setActiveElement] = useState<string | null>(null);
  const [aiMode, setAiMode] = useState(false);
  
  const elements = [
    { icon: <Move size={20} />, label: 'Select' },
    { icon: <Sofa size={20} />, label: 'Sofa' },
    { icon: <Bed size={20} />, label: 'Bed' },
    { icon: <Tv size={20} />, label: 'TV' },
    { icon: <Fridge size={20} />, label: 'Fridge' },
    { icon: <Bath size={20} />, label: 'Bath' },
    { icon: <Palette size={20} />, label: 'Colors' },
  ];
  
  const handleElementClick = (label: string) => {
    setActiveElement(label);
  };
  
  return (
    <div className="min-h-screen flex flex-col bg-neutral-50">
      <Header />
      
      <main className="flex-grow flex">
        {/* Left Panel - Element Selector */}
        <div className="w-20 bg-white shadow-md flex flex-col items-center py-4 overflow-auto">
          {elements.map((element) => (
            <DesignElement
              key={element.label}
              icon={element.icon}
              label={element.label}
              active={activeElement === element.label}
              onClick={() => handleElementClick(element.label)}
            />
          ))}
        </div>
        
        {/* Main Canvas Area */}
        <div className="flex-grow relative">
          {/* Canvas Background */}
          <div className="absolute inset-0 bg-neutral-100 grid grid-cols-[repeat(20,minmax(0,1fr))] grid-rows-[repeat(20,minmax(0,1fr))] gap-px">
            {[...Array(400)].map((_, index) => (
              <div key={index} className="bg-white" />
            ))}
          </div>
          
          {/* Example Room Layout */}
          <div className="absolute inset-16 bg-white border-2 border-neutral-300 rounded-xl flex items-center justify-center">
            <div className="text-neutral-400 text-center">
              <p className="mb-2">Select elements from the left panel</p>
              <p className="text-sm">or</p>
              <button 
                className="mt-2 text-primary-500 flex items-center justify-center gap-1"
                onClick={() => setAiMode(true)}
              >
                <MessageCircle size={16} />
                <span>Ask AI for suggestions</span>
              </button>
            </div>
          </div>
          
          {/* Bottom Toolbar */}
          <div className="absolute bottom-0 left-0 right-0 bg-white shadow-up py-3 px-6 flex justify-between items-center">
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                leftIcon={<Save size={16} />}
              >
                Save
              </Button>
              <Button
                variant="outline"
                size="sm"
                leftIcon={<Share2 size={16} />}
              >
                Share
              </Button>
              <Button
                variant="outline"
                size="sm"
                leftIcon={<Download size={16} />}
              >
                Export Blueprint
              </Button>
            </div>
            
            <div className="flex items-center">
              <span className="mr-3 text-sm text-neutral-600">Ask AI for suggestions</span>
              <div 
                className={`relative w-12 h-6 ${aiMode ? 'bg-primary-500' : 'bg-neutral-300'} rounded-full cursor-pointer transition-colors`}
                onClick={() => setAiMode(!aiMode)}
              >
                <div 
                  className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all duration-300 ${
                    aiMode ? 'left-7' : 'left-1'
                  }`}
                />
              </div>
            </div>
          </div>
          
          {/* AI Chat Overlay (when aiMode is true) */}
          {aiMode && (
            <div className="absolute bottom-16 right-6 w-80 bg-white rounded-lg shadow-lg overflow-hidden border border-neutral-200">
              <div className="bg-primary-500 text-white px-4 py-3 flex justify-between items-center">
                <h3 className="font-medium">AI Architect</h3>
                <button 
                  className="text-white"
                  onClick={() => setAiMode(false)}
                >
                  <X size={18} />
                </button>
              </div>
              
              <div className="h-80 overflow-y-auto p-4 bg-neutral-50">
                <div className="bg-primary-100 rounded-lg p-3 mb-3 max-w-[80%]">
                  <p className="text-sm">Hello! I'm your AI Architect. How can I help with your home design today?</p>
                </div>
                
                <div className="bg-neutral-200 rounded-lg p-3 mb-3 max-w-[80%] ml-auto">
                  <p className="text-sm">I want to design a 2BHK with good Vastu.</p>
                </div>
                
                <div className="bg-primary-100 rounded-lg p-3 mb-3 max-w-[80%]">
                  <p className="text-sm">For a Vastu-compliant 2BHK, I recommend:</p>
                  <ul className="text-sm list-disc pl-4 mt-1">
                    <li>Main entrance in N/E/SE direction</li>
                    <li>Master bedroom in SW corner</li>
                    <li>Kitchen in SE corner</li>
                    <li>Living room in N/NE area</li>
                  </ul>
                  <p className="text-sm mt-1">Should I create a basic layout for you?</p>
                </div>
              </div>
              
              <div className="p-3 border-t border-neutral-200 flex">
                <input 
                  type="text" 
                  placeholder="Type your question..." 
                  className="flex-grow rounded-lg border border-neutral-300 px-3 py-2 text-sm focus:outline-none focus:border-primary-500"
                />
                <button className="ml-2 bg-primary-500 text-white p-2 rounded-lg">
                  <MessageCircle size={18} />
                </button>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

// Add missing X icon
function X(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M18 6 6 18" />
      <path d="m6 6 12 12" />
    </svg>
  );
}

export default HomeDesigner;