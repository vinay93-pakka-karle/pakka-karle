import React, { useState } from 'react';
import { Calculator, ChevronDown, Info, BarChart2 } from 'lucide-react';
import Header from '../../components/layout/Header';
import Button from '../../components/ui/Button';
import Card, { CardContent } from '../../components/ui/Card';

interface HomeTypeOption {
  id: string;
  label: string;
  size: string;
}

interface MaterialCost {
  material: string;
  cost: number;
  unit: string;
  quantity: number;
  totalCost: number;
  icon: React.ReactNode;
}

const CostEstimator: React.FC = () => {
  const [selectedType, setSelectedType] = useState<string>('2bhk');
  const [customSqft, setCustomSqft] = useState<number>(800);
  const [isAdvancedOpen, setIsAdvancedOpen] = useState<boolean>(false);
  
  const homeTypeOptions: HomeTypeOption[] = [
    { id: '1bhk', label: '1 BHK', size: '400-600 sq.ft' },
    { id: '2bhk', label: '2 BHK', size: '700-900 sq.ft' },
    { id: '3bhk', label: '3 BHK', size: '1000-1300 sq.ft' },
    { id: 'custom', label: 'Custom Size', size: 'Enter sq.ft' }
  ];
  
  const materialCosts: MaterialCost[] = [
    { 
      material: 'Bricks', 
      cost: 8, 
      unit: 'per brick', 
      quantity: 8000, 
      totalCost: 64000,
      icon: <div className="w-8 h-8 bg-red-500 rounded-sm flex items-center justify-center text-white font-bold">B</div>
    },
    { 
      material: 'Cement', 
      cost: 380, 
      unit: 'per bag', 
      quantity: 110, 
      totalCost: 41800,
      icon: <div className="w-8 h-8 bg-gray-500 rounded-sm flex items-center justify-center text-white font-bold">C</div>
    },
    { 
      material: 'Steel', 
      cost: 65, 
      unit: 'per kg', 
      quantity: 900, 
      totalCost: 58500,
      icon: <div className="w-8 h-8 bg-blue-500 rounded-sm flex items-center justify-center text-white font-bold">S</div>
    },
    { 
      material: 'Sand', 
      cost: 1800, 
      unit: 'per ton', 
      quantity: 25, 
      totalCost: 45000,
      icon: <div className="w-8 h-8 bg-yellow-500 rounded-sm flex items-center justify-center text-white font-bold">S</div>
    },
    { 
      material: 'Aggregate', 
      cost: 2200, 
      unit: 'per ton', 
      quantity: 18, 
      totalCost: 39600,
      icon: <div className="w-8 h-8 bg-stone-500 rounded-sm flex items-center justify-center text-white font-bold">A</div>
    },
    { 
      material: 'Paint', 
      cost: 320, 
      unit: 'per liter', 
      quantity: 70, 
      totalCost: 22400,
      icon: <div className="w-8 h-8 bg-green-500 rounded-sm flex items-center justify-center text-white font-bold">P</div>
    }
  ];
  
  // Calculate total cost
  const totalCost = materialCosts.reduce((acc, item) => acc + item.totalCost, 0);
  
  const handleTypeChange = (id: string) => {
    setSelectedType(id);
  };
  
  return (
    <div className="min-h-screen flex flex-col bg-neutral-50">
      <Header />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-2xl font-bold text-neutral-900">Material Cost Estimator</h1>
            <p className="text-neutral-600">
              Get estimated costs for building your home
            </p>
          </div>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-md overflow-hidden">
              <div className="p-6 border-b border-neutral-200">
                <h2 className="text-lg font-semibold">Home Details</h2>
              </div>
              
              <div className="p-6 space-y-6">
                <div>
                  <label className="block text-sm font-medium text-neutral-700 mb-2">
                    Home Type
                  </label>
                  <div className="grid grid-cols-2 gap-3">
                    {homeTypeOptions.map((option) => (
                      <button
                        key={option.id}
                        className={`border ${
                          selectedType === option.id 
                            ? 'border-primary-500 bg-primary-50 text-primary-700' 
                            : 'border-neutral-300 bg-white hover:bg-neutral-50'
                        } rounded-lg p-3 transition-colors`}
                        onClick={() => handleTypeChange(option.id)}
                      >
                        <div className="font-medium">{option.label}</div>
                        <div className="text-sm text-neutral-500">{option.size}</div>
                      </button>
                    ))}
                  </div>
                </div>
                
                {selectedType === 'custom' && (
                  <div>
                    <label className="block text-sm font-medium text-neutral-700 mb-2">
                      Custom Area (sq.ft)
                    </label>
                    <input
                      type="number"
                      value={customSqft}
                      onChange={(e) => setCustomSqft(parseInt(e.target.value))}
                      className="w-full px-3 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500"
                    />
                  </div>
                )}
                
                <div>
                  <div 
                    className="flex justify-between items-center cursor-pointer"
                    onClick={() => setIsAdvancedOpen(!isAdvancedOpen)}
                  >
                    <span className="text-sm font-medium text-neutral-700">Advanced Options</span>
                    <ChevronDown
                      size={18}
                      className={`text-neutral-500 transition-transform ${isAdvancedOpen ? 'rotate-180' : ''}`}
                    />
                  </div>
                  
                  {isAdvancedOpen && (
                    <div className="mt-3 space-y-3">
                      <div>
                        <label className="block text-sm font-medium text-neutral-700 mb-2">
                          Number of Floors
                        </label>
                        <select className="w-full px-3 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500">
                          <option value="1">1 Floor</option>
                          <option value="2">2 Floors</option>
                          <option value="3">3 Floors</option>
                        </select>
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-neutral-700 mb-2">
                          Roof Type
                        </label>
                        <select className="w-full px-3 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500">
                          <option value="rcc">RCC Roof</option>
                          <option value="sloping">Sloping Roof</option>
                          <option value="metallic">Metallic Roof</option>
                        </select>
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-neutral-700 mb-2">
                          Standard of Finishing
                        </label>
                        <select className="w-full px-3 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500">
                          <option value="standard">Standard</option>
                          <option value="premium">Premium</option>
                          <option value="luxury">Luxury</option>
                        </select>
                      </div>
                    </div>
                  )}
                </div>
                
                <Button 
                  variant="primary" 
                  fullWidth
                  leftIcon={<Calculator size={18} />}
                >
                  Calculate Cost
                </Button>
                
                <div className="flex items-center justify-center">
                  <p className="text-sm text-neutral-500 flex items-center">
                    <Info size={14} className="mr-1" />
                    Prices are based on current market rates
                  </p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="lg:col-span-2">
            <Card className="mb-6">
              <CardContent>
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-xl font-semibold">Estimated Cost Breakdown</h2>
                  <Button 
                    variant="outline" 
                    size="sm"
                    leftIcon={<BarChart2 size={16} />}
                  >
                    Compare Brands
                  </Button>
                </div>
                
                <div className="border-t border-neutral-200 -mx-6"></div>
                
                <div className="divide-y divide-neutral-200">
                  {materialCosts.map((material, index) => (
                    <div key={index} className="py-4 flex items-center">
                      <div className="mr-4">
                        {material.icon}
                      </div>
                      <div className="flex-grow">
                        <div className="flex justify-between mb-1">
                          <h3 className="font-medium">{material.material}</h3>
                          <span className="font-semibold">₹{material.totalCost.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between text-sm text-neutral-500">
                          <span>₹{material.cost} {material.unit} × {material.quantity.toLocaleString()} units</span>
                          <span>{((material.totalCost / totalCost) * 100).toFixed(1)}%</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                
                <div className="border-t border-neutral-200 pt-4 mt-4">
                  <div className="flex justify-between items-center">
                    <div>
                      <h3 className="text-lg font-semibold">Total Estimated Cost</h3>
                      <p className="text-sm text-neutral-500">Based on {selectedType === 'custom' ? `${customSqft} sq.ft` : homeTypeOptions.find(opt => opt.id === selectedType)?.size}</p>
                    </div>
                    <div className="text-2xl font-bold text-primary-700">
                      ₹{totalCost.toLocaleString()}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <div className="bg-primary-50 border border-primary-200 rounded-xl p-5">
              <div className="flex items-start">
                <div className="bg-primary-100 p-2 rounded-full mr-4">
                  <Info size={20} className="text-primary-600" />
                </div>
                <div>
                  <h3 className="font-medium text-primary-800 mb-1">Upgrade for Real-time Pricing</h3>
                  <p className="text-sm text-primary-700 mb-3">
                    Get live material costs from local suppliers and compare prices from different brands.
                  </p>
                  <Button 
                    variant="primary" 
                    size="sm"
                  >
                    Upgrade Now
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default CostEstimator;