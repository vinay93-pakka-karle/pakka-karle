import React, { useState } from 'react';
import { Calendar, Clock, DollarSign, Zap, MapPin, Phone, Check } from 'lucide-react';
import Header from '../../components/layout/Header';
import Button from '../../components/ui/Button';
import Card, { CardContent } from '../../components/ui/Card';

interface ServiceOption {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
}

const InstantHelp: React.FC = () => {
  const [selectedService, setSelectedService] = useState<string>('fan');
  const [selectedDate, setSelectedDate] = useState<string>('today');
  const [selectedTime, setSelectedTime] = useState<string>('morning');
  const [expressDelivery, setExpressDelivery] = useState<boolean>(false);
  
  const services: ServiceOption[] = [
    {
      id: 'fan',
      name: 'Fan Installation',
      description: 'Installation and testing of ceiling or wall fans',
      price: 199,
      image: 'https://images.pexels.com/photos/11803048/pexels-photo-11803048.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    },
    {
      id: 'tv',
      name: 'TV Mounting',
      description: 'Secure mounting of TVs on walls with cable management',
      price: 299,
      image: 'https://images.pexels.com/photos/4009402/pexels-photo-4009402.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    },
    {
      id: 'ac',
      name: 'AC Service',
      description: 'Complete cleaning and maintenance service for air conditioners',
      price: 399,
      image: 'https://images.pexels.com/photos/7163531/pexels-photo-7163531.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    },
    {
      id: 'birdnet',
      name: 'Bird Net Installation',
      description: 'Installation of high-quality bird nets on balconies',
      price: 99,
      image: 'https://images.pexels.com/photos/9389139/pexels-photo-9389139.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    },
    {
      id: 'lock',
      name: 'Door Lock Installation',
      description: 'Installation or replacement of door locks with security check',
      price: 249,
      image: 'https://images.pexels.com/photos/4148865/pexels-photo-4148865.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    },
    {
      id: 'plumbing',
      name: 'Plumbing Service',
      description: 'Fixing leaks, clogs, and other plumbing issues',
      price: 299,
      image: 'https://images.pexels.com/photos/6000183/pexels-photo-6000183.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    },
  ];
  
  const selectedServiceObj = services.find(service => service.id === selectedService);
  
  const handleServiceChange = (serviceId: string) => {
    setSelectedService(serviceId);
  };
  
  const getTotalPrice = () => {
    const basePrice = selectedServiceObj?.price || 0;
    const expressCharge = expressDelivery ? 49 : 0;
    return basePrice + expressCharge;
  };
  
  return (
    <div className="min-h-screen flex flex-col bg-neutral-50">
      <Header />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-2xl font-bold text-neutral-900">Instant Home Help</h1>
            <p className="text-neutral-600">
              Book reliable home services with fixed pricing
            </p>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <div className="col-span-1 lg:col-span-2">
            <h2 className="text-lg font-semibold mb-4">Select a Service</h2>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
              {services.map((service) => (
                <div
                  key={service.id}
                  className={`border rounded-xl overflow-hidden cursor-pointer transition-all ${
                    selectedService === service.id 
                      ? 'border-primary-500 ring-2 ring-primary-500 ring-opacity-50' 
                      : 'border-neutral-200 hover:border-primary-200'
                  }`}
                  onClick={() => handleServiceChange(service.id)}
                >
                  <div className="relative h-36">
                    <img 
                      src={service.image} 
                      alt={service.name}
                      className="w-full h-full object-cover"
                    />
                    {selectedService === service.id && (
                      <div className="absolute top-2 right-2 bg-primary-500 text-white rounded-full p-1">
                        <Check size={16} />
                      </div>
                    )}
                  </div>
                  
                  <div className="p-3">
                    <div className="flex justify-between items-center mb-1">
                      <h3 className="font-medium">{service.name}</h3>
                      <span className="text-primary-700 font-semibold">₹{service.price}</span>
                    </div>
                    <p className="text-sm text-neutral-600">{service.description}</p>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <h2 className="text-lg font-semibold mb-4">Select Date</h2>
                <Card>
                  <CardContent>
                    <div className="space-y-3">
                      <label className="flex items-center p-3 border border-neutral-200 rounded-lg cursor-pointer">
                        <input 
                          type="radio" 
                          name="date" 
                          value="today"
                          checked={selectedDate === 'today'}
                          onChange={() => setSelectedDate('today')}
                          className="mr-3 h-4 w-4 text-primary-600 border-neutral-300 focus:ring-primary-500"
                        />
                        <span className="flex-grow">
                          <span className="block font-medium">Today</span>
                          <span className="block text-sm text-neutral-500">May 25, 2025</span>
                        </span>
                        <Calendar size={18} className="text-neutral-500" />
                      </label>
                      
                      <label className="flex items-center p-3 border border-neutral-200 rounded-lg cursor-pointer">
                        <input 
                          type="radio" 
                          name="date" 
                          value="tomorrow"
                          checked={selectedDate === 'tomorrow'}
                          onChange={() => setSelectedDate('tomorrow')}
                          className="mr-3 h-4 w-4 text-primary-600 border-neutral-300 focus:ring-primary-500"
                        />
                        <span className="flex-grow">
                          <span className="block font-medium">Tomorrow</span>
                          <span className="block text-sm text-neutral-500">May 26, 2025</span>
                        </span>
                        <Calendar size={18} className="text-neutral-500" />
                      </label>
                      
                      <label className="flex items-center p-3 border border-neutral-200 rounded-lg cursor-pointer">
                        <input 
                          type="radio" 
                          name="date" 
                          value="custom"
                          checked={selectedDate === 'custom'}
                          onChange={() => setSelectedDate('custom')}
                          className="mr-3 h-4 w-4 text-primary-600 border-neutral-300 focus:ring-primary-500"
                        />
                        <span className="flex-grow">
                          <span className="block font-medium">Choose Date</span>
                          <span className="block text-sm text-neutral-500">Pick any date</span>
                        </span>
                        <Calendar size={18} className="text-neutral-500" />
                      </label>
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              <div>
                <h2 className="text-lg font-semibold mb-4">Select Time</h2>
                <Card>
                  <CardContent>
                    <div className="space-y-3">
                      <label className="flex items-center p-3 border border-neutral-200 rounded-lg cursor-pointer">
                        <input 
                          type="radio" 
                          name="time" 
                          value="morning"
                          checked={selectedTime === 'morning'}
                          onChange={() => setSelectedTime('morning')}
                          className="mr-3 h-4 w-4 text-primary-600 border-neutral-300 focus:ring-primary-500"
                        />
                        <span className="flex-grow">
                          <span className="block font-medium">Morning</span>
                          <span className="block text-sm text-neutral-500">9:00 AM - 12:00 PM</span>
                        </span>
                        <Clock size={18} className="text-neutral-500" />
                      </label>
                      
                      <label className="flex items-center p-3 border border-neutral-200 rounded-lg cursor-pointer">
                        <input 
                          type="radio" 
                          name="time" 
                          value="afternoon"
                          checked={selectedTime === 'afternoon'}
                          onChange={() => setSelectedTime('afternoon')}
                          className="mr-3 h-4 w-4 text-primary-600 border-neutral-300 focus:ring-primary-500"
                        />
                        <span className="flex-grow">
                          <span className="block font-medium">Afternoon</span>
                          <span className="block text-sm text-neutral-500">1:00 PM - 4:00 PM</span>
                        </span>
                        <Clock size={18} className="text-neutral-500" />
                      </label>
                      
                      <label className="flex items-center p-3 border border-neutral-200 rounded-lg cursor-pointer">
                        <input 
                          type="radio" 
                          name="time" 
                          value="evening"
                          checked={selectedTime === 'evening'}
                          onChange={() => setSelectedTime('evening')}
                          className="mr-3 h-4 w-4 text-primary-600 border-neutral-300 focus:ring-primary-500"
                        />
                        <span className="flex-grow">
                          <span className="block font-medium">Evening</span>
                          <span className="block text-sm text-neutral-500">5:00 PM - 8:00 PM</span>
                        </span>
                        <Clock size={18} className="text-neutral-500" />
                      </label>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
          
          <div>
            <Card className="sticky top-4">
              <CardContent>
                <h2 className="text-lg font-semibold mb-4">Order Summary</h2>
                
                {selectedServiceObj && (
                  <div className="flex items-center mb-6">
                    <img 
                      src={selectedServiceObj.image} 
                      alt={selectedServiceObj.name}
                      className="w-16 h-16 object-cover rounded-lg mr-4"
                    />
                    <div>
                      <h3 className="font-medium">{selectedServiceObj.name}</h3>
                      <p className="text-sm text-neutral-600">{selectedServiceObj.description}</p>
                    </div>
                  </div>
                )}
                
                <div className="border-t border-b border-neutral-200 py-4 mb-4">
                  <div className="flex justify-between mb-2">
                    <span className="text-neutral-600">Service Fee</span>
                    <span>₹{selectedServiceObj?.price || 0}</span>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <input 
                        type="checkbox"
                        id="express"
                        checked={expressDelivery}
                        onChange={() => setExpressDelivery(!expressDelivery)}
                        className="mr-2 h-4 w-4 text-primary-600 border-neutral-300 focus:ring-primary-500"
                      />
                      <label htmlFor="express" className="flex items-center text-neutral-600">
                        <Zap size={16} className="text-accent-500 mr-1" />
                        Express 30-min Service
                      </label>
                    </div>
                    <span>+₹49</span>
                  </div>
                </div>
                
                <div className="flex justify-between items-center mb-6">
                  <span className="font-medium">Total</span>
                  <span className="text-xl font-bold text-primary-700">₹{getTotalPrice()}</span>
                </div>
                
                <div className="space-y-3 mb-6">
                  <div className="flex items-center text-sm text-neutral-700">
                    <MapPin size={16} className="mr-2 text-neutral-500" />
                    <span>Delivers to: 123 Main Street, Bangalore</span>
                  </div>
                  
                  <div className="flex items-center text-sm text-neutral-700">
                    <Calendar size={16} className="mr-2 text-neutral-500" />
                    <span>
                      {selectedDate === 'today' ? 'Today' : selectedDate === 'tomorrow' ? 'Tomorrow' : 'Custom date'}, 
                      {selectedTime === 'morning' ? ' Morning (9-12)' : selectedTime === 'afternoon' ? ' Afternoon (1-4)' : ' Evening (5-8)'}
                    </span>
                  </div>
                  
                  <div className="flex items-center text-sm text-neutral-700">
                    <Phone size={16} className="mr-2 text-neutral-500" />
                    <span>Contact: +91 98765 43210</span>
                  </div>
                </div>
                
                <Button 
                  variant="primary" 
                  fullWidth
                  leftIcon={<DollarSign size={18} />}
                >
                  Book Now
                </Button>
                
                <p className="text-xs text-neutral-500 text-center mt-4">
                  By booking, you agree to our terms and conditions
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
};

export default InstantHelp;