import React from 'react';
import { 
  ActivitySquare, 
  MessageCircle, 
  Calculator,
  Briefcase, 
  Home, 
  Zap, 
  Building, 
  Calendar,
  User
} from 'lucide-react';
import Card, { CardContent } from '../../components/ui/Card';
import Header from '../../components/layout/Header';

interface AppCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  bgColor: string;
  onClick?: () => void;
}

const AppCard: React.FC<AppCardProps> = ({ 
  icon, 
  title, 
  description, 
  bgColor,
  onClick
}) => {
  return (
    <Card 
      hoverable 
      className="h-full border border-neutral-200 transition-all duration-300"
      onClick={onClick}
    >
      <CardContent className="flex flex-col items-center p-6">
        <div className={`p-4 rounded-full mb-4 ${bgColor}`}>
          {icon}
        </div>
        <h3 className="text-lg font-semibold mb-2 text-center">{title}</h3>
        <p className="text-neutral-600 text-center text-sm">{description}</p>
      </CardContent>
    </Card>
  );
};

const Dashboard: React.FC = () => {
  const userName = "Rahul";
  
  const appCards = [
    {
      icon: <ActivitySquare size={24} />,
      title: "Design Your Home in 3D",
      description: "Create and customize your dream home with our intuitive 3D designer",
      bgColor: "bg-primary-100 text-primary-600",
      path: "/designer"
    },
    {
      icon: <MessageCircle size={24} />,
      title: "AI Architect - Ask Anything",
      description: "Get expert advice from our AI on design, Vastu, materials, and more",
      bgColor: "bg-accent-100 text-accent-600",
      path: "/chat"
    },
    {
      icon: <Briefcase size={24} />,
      title: "Nearby Helpers",
      description: "Find reliable electricians, plumbers, and other workers near you",
      bgColor: "bg-green-100 text-green-600",
      path: "/services"
    },
    {
      icon: <Calculator size={24} />,
      title: "Estimate Your House Cost",
      description: "Get detailed cost estimates for your construction project",
      bgColor: "bg-purple-100 text-purple-600",
      path: "/estimator"
    },
    {
      icon: <Home size={24} />,
      title: "List Property for Sale/Rent",
      description: "List your property for free with zero commission",
      bgColor: "bg-red-100 text-red-600",
      path: "/property"
    },
    {
      icon: <Zap size={24} />,
      title: "Quick Fixes",
      description: "Book instant services for small home repairs and installations",
      bgColor: "bg-orange-100 text-orange-600",
      path: "/fixes"
    }
  ];
  
  return (
    <div className="min-h-screen flex flex-col bg-neutral-50">
      <Header />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-2xl font-bold text-neutral-900">
              Welcome, {userName} 👋
            </h1>
            <p className="text-neutral-600">
              What would you like to do today?
            </p>
          </div>
          
          <button className="bg-primary-500 text-white rounded-full p-3 shadow-lg hover:bg-primary-600 transition-colors">
            <User size={24} />
          </button>
        </div>
        
        <div className="bg-gradient-to-r from-primary-500 to-primary-600 rounded-xl p-6 mb-8 shadow-md">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="text-white mb-4 md:mb-0">
              <h2 className="text-xl font-semibold mb-2">Ready to start your project?</h2>
              <p className="opacity-90">Talk to our AI architect for personalized guidance</p>
            </div>
            
            <button className="bg-white text-primary-600 font-medium px-4 py-2 rounded-lg hover:bg-neutral-100 transition-colors">
              Start Now
            </button>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {appCards.map((card, index) => (
            <AppCard
              key={index}
              icon={card.icon}
              title={card.title}
              description={card.description}
              bgColor={card.bgColor}
            />
          ))}
        </div>
        
        <div className="mt-8 bg-white rounded-xl shadow-md p-6">
          <h2 className="text-xl font-semibold mb-4">Recent Activity</h2>
          
          <div className="space-y-4">
            <div className="flex items-start p-3 border border-neutral-200 rounded-lg hover:bg-neutral-50">
              <div className="bg-primary-100 p-2 rounded-full mr-4">
                <Building size={20} className="text-primary-600" />
              </div>
              <div>
                <h3 className="font-medium">3D Home Design Updated</h3>
                <p className="text-sm text-neutral-600">You updated your 2BHK design</p>
                <p className="text-xs text-neutral-400 mt-1">Yesterday at 4:30 PM</p>
              </div>
            </div>
            
            <div className="flex items-start p-3 border border-neutral-200 rounded-lg hover:bg-neutral-50">
              <div className="bg-green-100 p-2 rounded-full mr-4">
                <Calendar size={20} className="text-green-600" />
              </div>
              <div>
                <h3 className="font-medium">Electrician Appointment</h3>
                <p className="text-sm text-neutral-600">Scheduled for tomorrow at 10:00 AM</p>
                <p className="text-xs text-neutral-400 mt-1">2 days ago</p>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Dashboard;