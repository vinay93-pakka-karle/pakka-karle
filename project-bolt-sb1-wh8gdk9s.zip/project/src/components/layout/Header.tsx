import React, { useState, useEffect } from 'react';
import { Menu, X, Home, Activity, MessageCircle, Calculator, Briefcase, User } from 'lucide-react';
import Button from '../ui/Button';

interface NavLink {
  name: string;
  href: string;
  icon?: React.ReactNode;
}

const navLinks: NavLink[] = [
  { name: 'Home', href: '/', icon: <Home size={18} /> },
  { name: '3D Designer', href: '/designer', icon: <Activity size={18} /> },
  { name: 'AI Chat', href: '/chat', icon: <MessageCircle size={18} /> },
  { name: 'Cost Estimator', href: '/estimator', icon: <Calculator size={18} /> },
  { name: 'Services', href: '/services', icon: <Briefcase size={18} /> },
  { name: 'My Account', href: '/account', icon: <User size={18} /> },
];

interface HeaderProps {
  isHomePage?: boolean;
}

const Header: React.FC<HeaderProps> = ({ isHomePage = false }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);

  const headerClasses = isHomePage
    ? `fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white shadow-md py-2' : 'bg-transparent py-4'
      }`
    : 'bg-white shadow-md py-2';

  const textColor = isHomePage && !isScrolled ? 'text-white' : 'text-neutral-900';

  return (
    <header className={headerClasses}>
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <a href="/" className="flex items-center">
              <span className={`text-2xl font-bold ${textColor}`}>
                <span className="text-primary-500">Pakka</span> Karle
              </span>
            </a>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-4">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className={`flex items-center px-3 py-2 rounded-md text-sm font-medium ${
                  isHomePage && !isScrolled
                    ? 'text-white hover:bg-white hover:bg-opacity-20'
                    : 'text-neutral-700 hover:bg-neutral-100'
                }`}
              >
                {link.icon && <span className="mr-1.5">{link.icon}</span>}
                {link.name}
              </a>
            ))}
            <Button variant="primary" size="sm">
              Try Free Demo
            </Button>
          </nav>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button
              onClick={toggleMenu}
              className={`p-2 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 ${textColor}`}
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Menu */}
        {isMenuOpen && (
          <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  className="flex items-center px-3 py-2 rounded-md text-base font-medium text-neutral-700 hover:bg-neutral-100"
                  onClick={() => setIsMenuOpen(false)}
                >
                  {link.icon && <span className="mr-2">{link.icon}</span>}
                  {link.name}
                </a>
              ))}
              <div className="pt-2">
                <Button variant="primary" fullWidth>
                  Try Free Demo
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;