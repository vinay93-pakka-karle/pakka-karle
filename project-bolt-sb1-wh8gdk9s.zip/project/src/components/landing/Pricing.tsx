import React, { useState } from 'react';
import { Check } from 'lucide-react';
import Button from '../ui/Button';

interface PriceToggleProps {
  monthly: boolean;
  onToggle: () => void;
}

const PriceToggle: React.FC<PriceToggleProps> = ({ monthly, onToggle }) => {
  return (
    <div className="flex items-center justify-center mb-8">
      <span className={`mr-3 ${monthly ? 'text-neutral-900 font-medium' : 'text-neutral-500'}`}>
        Monthly
      </span>
      <div 
        className="relative w-14 h-7 bg-primary-200 rounded-full cursor-pointer"
        onClick={onToggle}
      >
        <div 
          className={`absolute top-1 w-5 h-5 bg-primary-500 rounded-full transition-all duration-300 ${
            monthly ? 'left-1' : 'left-8'
          }`}
        />
      </div>
      <span className={`ml-3 ${!monthly ? 'text-neutral-900 font-medium' : 'text-neutral-500'}`}>
        Daily
      </span>
    </div>
  );
};

interface PlanFeature {
  text: string;
  available: boolean;
}

interface PricingPlanProps {
  title: string;
  monthlyPrice: number;
  dailyPrice: number;
  monthly: boolean;
  features: PlanFeature[];
  popular?: boolean;
  cta?: string;
}

const PricingPlan: React.FC<PricingPlanProps> = ({
  title,
  monthlyPrice,
  dailyPrice,
  monthly,
  features,
  popular = false,
  cta = 'Choose Plan'
}) => {
  const price = monthly ? monthlyPrice : dailyPrice;
  
  return (
    <div className={`relative rounded-xl shadow-lg overflow-hidden ${
      popular ? 'border-2 border-primary-500 transform -translate-y-4 md:-translate-y-6' : 'border border-neutral-200'
    }`}>
      {popular && (
        <div className="absolute top-0 left-0 right-0 bg-primary-500 text-white text-center py-1 text-sm font-medium">
          Most Popular
        </div>
      )}
      
      <div className={`px-6 py-8 ${popular ? 'pt-10' : ''}`}>
        <h3 className="text-2xl font-bold text-neutral-900 mb-2">{title}</h3>
        
        <div className="flex items-baseline mb-4">
          <span className="text-4xl font-extrabold">₹{price}</span>
          <span className="text-neutral-600 ml-1">/{monthly ? 'month' : 'day'}</span>
        </div>
        
        <ul className="mb-8 space-y-4">
          {features.map((feature, index) => (
            <li key={index} className="flex items-start">
              <div className={`mt-1 mr-2 ${feature.available ? 'text-primary-500' : 'text-neutral-400'}`}>
                <Check size={16} />
              </div>
              <span className={feature.available ? 'text-neutral-700' : 'text-neutral-400'}>
                {feature.text}
              </span>
            </li>
          ))}
        </ul>
        
        <Button 
          variant={popular ? 'primary' : 'outline'} 
          fullWidth
        >
          {cta}
        </Button>
      </div>
    </div>
  );
};

const Pricing: React.FC = () => {
  const [monthly, setMonthly] = useState(true);
  
  const plans = [
    {
      title: 'Free',
      monthlyPrice: 0,
      dailyPrice: 0,
      features: [
        { text: 'Basic 3D Designer', available: true },
        { text: 'Limited AI Chat (GPT-3.5)', available: true },
        { text: 'Basic Material Costing', available: true },
        { text: 'Property Listing (1 active)', available: true },
        { text: 'Voice Mode', available: false },
        { text: 'Blueprint Downloads', available: false },
        { text: 'Real-Time Cost Updates', available: false }
      ],
      cta: 'Start Free'
    },
    {
      title: 'Basic',
      monthlyPrice: 499,
      dailyPrice: 29,
      features: [
        { text: 'Advanced 3D Designer', available: true },
        { text: 'Enhanced AI Chat (GPT-3.5)', available: true },
        { text: 'Detailed Material Costing', available: true },
        { text: 'Property Listing (5 active)', available: true },
        { text: 'Voice Mode (Limited)', available: true },
        { text: 'Blueprint Downloads', available: false },
        { text: 'Real-Time Cost Updates', available: false }
      ],
      popular: true
    },
    {
      title: 'Pro',
      monthlyPrice: 899,
      dailyPrice: 49,
      features: [
        { text: 'Premium 3D Designer', available: true },
        { text: 'Premium AI Chat (GPT-4)', available: true },
        { text: 'Comprehensive Material Costing', available: true },
        { text: 'Property Listing (Unlimited)', available: true },
        { text: 'Full Voice Mode', available: true },
        { text: 'Blueprint Downloads', available: true },
        { text: 'Real-Time Cost Updates', available: true }
      ]
    },
    {
      title: 'Business',
      monthlyPrice: 1199,
      dailyPrice: 69,
      features: [
        { text: 'Enterprise 3D Designer', available: true },
        { text: 'Enterprise AI Chat (GPT-4)', available: true },
        { text: 'Enterprise Material Costing', available: true },
        { text: 'Property Listing (Unlimited)', available: true },
        { text: 'Full Voice Mode', available: true },
        { text: 'Blueprint Downloads', available: true },
        { text: 'Real-Time Cost Updates', available: true }
      ]
    }
  ];
  
  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Choose the Perfect <span className="text-primary-500">Plan</span> for You
          </h2>
          <p className="text-xl text-neutral-600 max-w-3xl mx-auto">
            Select a plan that works best for your needs. All plans include basic features with more advanced options as you upgrade.
          </p>
          
          <PriceToggle 
            monthly={monthly} 
            onToggle={() => setMonthly(!monthly)} 
          />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {plans.map((plan, index) => (
            <PricingPlan
              key={index}
              title={plan.title}
              monthlyPrice={plan.monthlyPrice}
              dailyPrice={plan.dailyPrice}
              monthly={monthly}
              features={plan.features}
              popular={plan.popular}
              cta={plan.cta}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Pricing;