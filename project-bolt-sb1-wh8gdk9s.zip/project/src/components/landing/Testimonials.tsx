import React from 'react';

interface TestimonialProps {
  quote: string;
  name: string;
  title: string;
  imgSrc: string;
  starCount: number;
}

const Testimonial: React.FC<TestimonialProps> = ({
  quote,
  name,
  title,
  imgSrc,
  starCount
}) => {
  return (
    <div className="bg-white rounded-xl shadow-md p-6 md:p-8">
      <div className="flex space-x-1 mb-4">
        {[...Array(5)].map((_, i) => (
          <svg 
            key={i} 
            className={`w-5 h-5 ${i < starCount ? 'text-accent-400' : 'text-neutral-300'}`} 
            fill="currentColor" 
            viewBox="0 0 20 20"
          >
            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
          </svg>
        ))}
      </div>
      
      <p className="text-neutral-700 mb-6 italic">{quote}</p>
      
      <div className="flex items-center">
        <img 
          src={imgSrc} 
          alt={name} 
          className="w-12 h-12 rounded-full mr-4"
        />
        <div>
          <h4 className="font-semibold text-neutral-900">{name}</h4>
          <p className="text-neutral-500 text-sm">{title}</p>
        </div>
      </div>
    </div>
  );
};

const Testimonials: React.FC = () => {
  const testimonials = [
    {
      quote: "Pakka Karle transformed how I built my home. The AI suggestions saved me lakhs of rupees on materials, and the 3D design tool made it easy to visualize everything.",
      name: "Rajesh Sharma",
      title: "Homeowner, Delhi",
      imgSrc: "https://randomuser.me/api/portraits/men/32.jpg",
      starCount: 5
    },
    {
      quote: "I was worried about home construction being complicated, but the app made everything transparent. The real-time cost estimator helped me stay on budget.",
      name: "Priya Patel",
      title: "First-time Builder, Mumbai",
      imgSrc: "https://randomuser.me/api/portraits/women/44.jpg",
      starCount: 4
    },
    {
      quote: "As an architect, I recommend Pakka Karle to all my clients. The AI chat feature answers their questions when I'm not available and the 3D tools are excellent.",
      name: "Arjun Kapoor",
      title: "Architect, Bangalore",
      imgSrc: "https://randomuser.me/api/portraits/men/67.jpg",
      starCount: 5
    },
  ];

  return (
    <section className="py-20 bg-neutral-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            What Our Users <span className="text-primary-500">Say</span>
          </h2>
          <p className="text-xl text-neutral-600 max-w-3xl mx-auto">
            Join thousands of satisfied users who have transformed their home building experience with Pakka Karle.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <Testimonial
              key={index}
              quote={testimonial.quote}
              name={testimonial.name}
              title={testimonial.title}
              imgSrc={testimonial.imgSrc}
              starCount={testimonial.starCount}
            />
          ))}
        </div>
        
        <div className="mt-12 text-center">
          <div className="inline-flex items-center bg-primary-50 text-primary-700 px-4 py-2 rounded-full font-medium text-sm">
            <span className="mr-2">⭐</span>
            Trusted by 10,000+ users across India with an average rating of 4.9/5
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;