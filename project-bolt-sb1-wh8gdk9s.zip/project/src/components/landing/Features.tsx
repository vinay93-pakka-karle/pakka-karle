import React from 'react';
import { Home, MessageCircle, Calculator, Settings, Mic, Home as HomeIcon } from 'lucide-react';
import Card, { CardContent } from '../ui/Card';

interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  delay?: number;
}

const FeatureCard: React.FC<FeatureCardProps> = ({ 
  icon, 
  title, 
  description,
  delay = 0
}) => {
  return (
    <Card 
      hoverable 
      className={`h-full transform hover:scale-105 transition-all duration-300 animate-slide-in bg-gradient-to-br from-white to-neutral-50`}
      style={{ animationDelay: `${delay}ms` }}
    >
      <CardContent>
        <div className="flex flex-col items-center text-center">
          <div className="p-4 bg-gradient-to-br from-primary-100 to-primary-50 text-primary-600 rounded-2xl mb-4 animate-pulse-slow">
            {icon}
          </div>
          <h3 className="text-xl font-semibold mb-2 bg-clip-text text-transparent bg-gradient-to-r from-neutral-900 to-primary-700">
            {title}
          </h3>
          <p className="text-neutral-600">{description}</p>
        </div>
      </CardContent>
    </Card>
  );
};

const Features: React.FC = () => {
  const features = [
    {
      icon: <Home size={24} />,
      title: '3D Home Designer',
      description: 'Design your dream home in 3D with our intuitive tools. Customize every aspect from layout to furniture.'
    },
    {
      icon: <MessageCircle size={24} />,
      title: 'AI Chat Architect',
      description: 'Get expert advice from our GPT-powered AI architect. Ask anything about design, materials, or costs.'
    },
    {
      icon: <Calculator size={24} />,
      title: 'Real-Time Material Costing',
      description: 'Get instant cost estimates for your projects with real-time material pricing and labor costs.'
    },
    {
      icon: <Settings size={24} />,
      title: 'Instant Home Help',
      description: 'Book reliable services for your home - electricians, plumbers, AC repair, and more in just a few taps.'
    },
    {
      icon: <Mic size={24} />,
      title: 'Voice Assistant Mode',
      description: 'Control the app hands-free with voice commands. Perfect when you\'re at the construction site.'
    },
    {
      icon: <HomeIcon size={24} />,
      title: 'Sell/Rent Property',
      description: 'List your property for sale or rent without any commission. Connect directly with buyers.'
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-b from-neutral-50 to-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-primary-600 to-primary-400">
            Smart Features for Your <span className="text-accent-400">Home Journey</span>
          </h2>
          <p className="text-xl text-neutral-600 max-w-3xl mx-auto">
            Pakka Karle combines AI technology with construction expertise to make home building simple, transparent and hassle-free.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <FeatureCard
              key={index}
              icon={feature.icon}
              title={feature.title}
              description={feature.description}
              delay={index * 100}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;